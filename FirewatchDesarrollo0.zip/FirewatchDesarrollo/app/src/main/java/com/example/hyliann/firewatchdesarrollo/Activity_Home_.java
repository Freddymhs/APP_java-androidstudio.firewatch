package com.example.hyliann.firewatchdesarrollo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Activity_Home_ extends AppCompatActivity {
    //deslizar
    ///opciones d ebotones
    ///bateria
    //menu de home
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__home_);
        //
        String nombreDispositivo = "";
        setTitle("Dispositivo #" + nombreDispositivo);
        //
    }
}
