package com.example.hyliann.firewatchdesarrollo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HOME_Monitorizar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home__monitorizar);


    }
}
