package com.example.hyliann.firewatchdesarrollo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PantallaBienvenida extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_bienvenida);
        //carga la pantalla luego de carga la app
        startActivity(new Intent(PantallaBienvenida.this, MainActivity.class));
        finish();
    }
}
