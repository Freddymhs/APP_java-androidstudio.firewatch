package com.example.hyliann.firewatchdesarrollo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Activity_Home_ extends AppCompatActivity {
    //deslizar
    ///opciones d ebotones
    ///bateria
    //menu de home
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__home_);

        String nombreDispositivo = ""; //               name
        setTitle("Dispositivo #" + nombreDispositivo);// name
    }


    @Override//Barra
    public boolean onCreateOptionsMenu(Menu menu) { //0
        MenuInflater inflater = getMenuInflater();//1
        inflater.inflate(R.menu.barra_item, menu); // 2

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.item_home:
                Intent intento = new Intent(this, Activity_Home_.class);//intento a home
                startActivity(intento);//intento a home

        }
        return super.onOptionsItemSelected(item);
    }

//fin Barra
}
